package com.anishorts.ai;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    // Replace this with the HTTPS address of your deployed AniShorts web backend.
    private static final String APP_URL = "https://YOUR-ANISHORTS-APP-URL";
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (APP_URL.contains("YOUR-ANISHORTS-APP-URL")) { showSetup(); return; }
        WebView web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.loadUrl(APP_URL);
        setContentView(web);
    }
    private void showSetup() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL); box.setGravity(Gravity.CENTER);
        box.setPadding(32,32,32,32); box.setBackgroundColor(Color.rgb(11,16,32));
        TextView title = new TextView(this); title.setText("AniShorts AI"); title.setTextSize(30); title.setTextColor(Color.WHITE); title.setGravity(Gravity.CENTER);
        TextView note = new TextView(this); note.setText("Your Android app shell is ready.\n\nNext: publish the AniShorts web engine, then add its HTTPS address in MainActivity.java and rebuild the APK.\n\nVideo generation and YouTube upload need API credentials and an online backend."); note.setTextSize(16); note.setTextColor(Color.LTGRAY); note.setGravity(Gravity.CENTER); note.setPadding(0,24,0,0);
        box.addView(title); box.addView(note); setContentView(box);
    }
    @Override public void onBackPressed() { super.onBackPressed(); }
}
