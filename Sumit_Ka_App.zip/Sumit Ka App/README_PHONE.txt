ANISHORTS AI — ANDROID APK PROJECT

This is an Android WebView app shell plus a cloud APK build workflow. It is NOT yet the finished AI video generator.

PHONE-ONLY BUILD STEPS
1. Create/sign in to a GitHub account and create a NEW PUBLIC repository named AniShortsAI (do not upload API keys or passwords).
2. On GitHub mobile website, open the repository and upload every file/folder from this ZIP, preserving folder structure. The .github/workflows/build-apk.yml file is important.
3. Open the repository's Actions tab. If asked, enable GitHub Actions. Run “Build AniShorts APK” using “Run workflow”, or push/upload a commit to main.
4. When the workflow finishes, open its run, scroll to Artifacts, and download AniShorts-AI-debug-apk. Extract it and install app-debug.apk. Android may ask you to allow installation from that browser/files app.

IMPORTANT LIMITATIONS
- This first APK is only a mobile app shell. It shows setup instructions until an HTTPS hosted AniShorts backend is configured.
- To make generation work, deploy the existing Python app (AniShorts_AI/app.py) to a Python host, configure Replicate and YouTube OAuth securely on the server, then replace APP_URL in MainActivity.java with that HTTPS URL and rebuild.
- Never put Replicate tokens, Google client secrets, or YouTube access tokens in the Android source code or a public GitHub repository.
- AI video generation may cost money. Keep YouTube uploads private until reviewed.
